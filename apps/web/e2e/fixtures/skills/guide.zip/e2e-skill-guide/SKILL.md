---
name: e2e-skill-guide
description: A writing checklist for a browser test.
---

# Writing checklist

Use references/style.md when preparing a short answer.
