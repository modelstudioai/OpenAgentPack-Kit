# Style

Write a clear and concise answer.
